const https = require('https');
const crypto = require('crypto');

function mkLookup(ip){
  return function(h, o, cb){
    if(typeof o === 'function'){ cb = o; o = {}; }
    cb(null, ip, 4);
  };
}

function reqResolved(opts, ipList, body, timeoutMs){
  const ips = ipList && ipList.length ? ipList : [null];
  let attempt = 0;
  return new Promise((resolve, reject) => {
    function go(){
      const ip = ips[attempt];
      const o = Object.assign({}, opts);
      o.family = 4;
      if(ip) o.lookup = mkLookup(ip);
      const r = https.request(o, resp => {
        let b = '';
        resp.on('data', c => b += c);
        resp.on('end', () => resolve({ status: resp.statusCode, body: b }));
      });
      r.on('error', e => {
        attempt++;
        if(attempt < ips.length) go();
        else reject(e);
      });
      if(timeoutMs){ r.setTimeout(timeoutMs, () => r.destroy(new Error('timeout'))); }
      if(body) r.write(body);
      r.end();
    }
    go();
  });
}

// ============ vvhan ============
async function fetchVvhan(){
  const p = await reqResolved({
    host:'api.4ce.cn', path:'/api/bestCFIP', method:'GET',
    headers:{'User-Agent':'Mozilla/5.0','Accept':'application/json'}
  }, ['104.16.0.0','104.16.1.0','104.17.0.1'], null, 15000);
  const j = JSON.parse(p.body);
  const items = (j && j.data && j.data.items) || [];
  const updatedAt = (j && j.data && j.data.updatedAt) || new Date().toISOString();
  const norm = items.map(it => ({
    ip: it.ip,
    line: it.line || '',
    line_name: it.name || '',
    rtt_avg: it.latency != null ? it.latency : 0,
    speed: it.speed != null ? Math.round(it.speed * 1000) : 0,
    loss_rate: it.loss != null ? it.loss : 0,
    checkedAt: it.checkedAt || ''
  }));
  return { fetchedAt: new Date().toISOString(), updatedAt, items: norm };
}

// ============ v2rayssr ============
function parseV2Rows(html){
  const rows = [];
  const re = /<tr[^>]*>([\s\S]*?)<\/tr>/g;
  let m;
  while((m = re.exec(html))){
    const tds = [];
    const tdRe = /<td[^>]*>([\s\S]*?)<\/td>/g;
    let t;
    while((t = tdRe.exec(m[1]))) tds.push(t[1].replace(/<[^>]+>/g,'').replace(/&nbsp;/g,' ').replace(/已复制!|复制成功|已复制/g,'').trim());
    if(tds.length >= 8){
      const num = tds[0];
      const ip = tds[2];
      if(!/^\d+$/.test(num) || !ip) continue;
      if(ip.indexOf('.') < 0 && ip.indexOf(':') < 0) continue;
      rows.push({
        line_name: tds[1] || '',
        ip: ip,
        loss_rate: parseFloat(tds[3]) || 0,
        rtt_avg: parseFloat(tds[4]) || 0,
        speed: Math.round((parseFloat(tds[5]) || 0) * 1000),
        bandwidth: parseFloat(tds[6]) || 0,
        colo: tds[7] === '-' ? '' : tds[7],
        updated_at: tds[8] || ''
      });
    }
  }
  return rows;
}
const V2_IPS = ['104.16.0.0','104.16.1.0','104.17.0.1','104.17.1.0','1.1.1.1','1.0.0.1'];
async function fetchV2rayssr(){
  const ts = new Date().toISOString();
  let lastErr = null;
  for(const ip of V2_IPS){
    try{
      const p = await reqResolved({
        host:'v2rayssr.com', path:'/cfip/', method:'GET',
        headers:{'User-Agent':'Mozilla/5.0','Accept':'text/html,*/*'}
      }, [ip], null, 15000);
      if(p.status !== 200){ lastErr = new Error('http '+p.status); continue; }
      const items = parseV2Rows(p.body);
      if(!items.length){ lastErr = new Error('empty rows'); continue; }
      return { fetchedAt: ts, updatedAt: ts, items };
    }catch(e){
      lastErr = e;
    }
  }
  throw lastErr || new Error('v2rayssr all ips failed');
}

// ============ vps789 ============
const TOKEN_KEY = '385f33cb91484b04a177828829081ab7';
const DEC_KEY   = '125f33c891484b046777828569081a34';
const IV        = '00000000';
function desEncHex(msg, keyStr){
  const k = Buffer.from(keyStr.slice(0,8), 'utf8');
  const iv = Buffer.from(IV, 'utf8');
  const c = crypto.createCipheriv('des-cbc', k, iv);
  c.setAutoPadding(true);
  return Buffer.concat([c.update(Buffer.from(msg,'utf8')), c.final()]).toString('hex');
}
function desDecHex(hex, keyStr){
  const k = Buffer.from(keyStr.slice(0,8), 'utf8');
  const iv = Buffer.from(IV, 'utf8');
  const d = crypto.createDecipheriv('des-cbc', k, iv);
  d.setAutoPadding(true);
  return Buffer.concat([d.update(Buffer.from(hex,'hex')), d.final()]).toString('utf8');
}
async function callVps(path, payload){
  const token = desEncHex(String(Date.now()), TOKEN_KEY);
  const body = JSON.stringify(payload);
  const p = await reqResolved({
    host:'vps789.com', path, method:'POST',
    headers:{'Content-Type':'application/json','token':token,'User-Agent':'Mozilla/5.0'}
  }, null, body, 15000);
  const j = JSON.parse(p.body);
  if(j.message && typeof j.message === 'string' && j.message.length > 16){
    return JSON.parse(desDecHex(j.message, DEC_KEY));
  }
  return j;
}
async function fetchVps789(){
  const [ipPage, cnamePage] = await Promise.all([
    callVps('/public/cfMonitorList', { criteria:{remarks:{equals:'ip'}}, page:{number:1,size:200, sort:['createdTime,asc']} }),
    callVps('/public/cfMonitorList', { criteria:{remarks:{equals:'domain'}}, page:{number:1,size:1000, sort:['createdTime,asc']} })
  ]);
  const normIp = (ipPage.content || []).map(x => ({
    ip: x.ip,
    avgLat: x.avgLatency != null ? x.avgLatency : 0,
    avgLoss: x.avgPkgLostRate != null ? x.avgPkgLostRate : 0,
    dxLat: x.dxLatencyAvg != null ? x.dxLatencyAvg : 0,
    dxLoss: x.dxPkgLostRateAvg != null ? x.dxPkgLostRateAvg : 0,
    dxRoute: x.dxRoute || '',
    dxLine: x.dxLineType || '',
    ydLat: x.ydLatencyAvg != null ? x.ydLatencyAvg : 0,
    ydLoss: x.ydPkgLostRateAvg != null ? x.ydPkgLostRateAvg : 0,
    ydRoute: x.ydRoute || '',
    ydLine: x.ydLineType || '',
    ltLat: x.ltLatencyAvg != null ? x.ltLatencyAvg : 0,
    ltLoss: x.ltPkgLostRateAvg != null ? x.ltPkgLostRateAvg : 0,
    ltRoute: x.ltRoute || '',
    ltLine: x.ltLineType || '',
    top: x.top || '0',
    updated: x.createdTime || 0
  }));
  const normCname = (cnamePage.content || []).map(x => ({
    domain: x.ip || '',
    host: x.hostProvider || '',
    ctry: x.locationCountry || '',
    city: x.locationCity || '',
    avgLat: x.avgLatency != null ? x.avgLatency : 0,
    avgLoss: x.avgPkgLostRate != null ? x.avgPkgLostRate : 0,
    dxLat: x.dxLatencyAvg != null ? x.dxLatencyAvg : 0,
    dxLoss: x.dxPkgLostRateAvg != null ? x.dxPkgLostRateAvg : 0,
    dxRoute: x.dxRoute || '',
    ydLat: x.ydLatencyAvg != null ? x.ydLatencyAvg : 0,
    ydLoss: x.ydPkgLostRateAvg != null ? x.ydPkgLostRateAvg : 0,
    ydRoute: x.ydRoute || '',
    ltLat: x.ltLatencyAvg != null ? x.ltLatencyAvg : 0,
    ltLoss: x.ltPkgLostRateAvg != null ? x.ltPkgLostRateAvg : 0,
    ltRoute: x.ltRoute || '',
    downloadSpeed: x.downloadSpeed || '',
    sponsor: x.sponsorName || '',
    updated: x.createdTime || 0
  }));
  return { fetchedAt: new Date().toISOString(), ip: normIp, cname: normCname };
}

module.exports = { fetchVvhan, fetchV2rayssr, fetchVps789 };
