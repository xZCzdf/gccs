const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const live = require('./live.js');

const PORT = process.env.PORT || 8000;
const ROOT = __dirname;
const UPSTREAM = 'www.wetest.vip';

const LIVE_SOURCES = {
  vvhan:    { fetch: () => live.fetchVvhan(),    ttl: 5 * 60 * 1000 },
  v2rayssr: { fetch: () => live.fetchV2rayssr(), ttl: 10 * 60 * 1000 },
  vps789:   { fetch: () => live.fetchVps789(),   ttl: 10 * 60 * 1000 }
};
const liveCache = {};
function getLive(name){
  const src = LIVE_SOURCES[name];
  if(!src) return Promise.resolve(null);
  const now = Date.now();
  if(liveCache[name] && now - liveCache[name].at < src.ttl){
    return Promise.resolve(liveCache[name].data);
  }
  return src.fetch().then(data => {
    liveCache[name] = { at: now, data };
    return data;
  });
}
const mime = {
  '.html':'text/html; charset=utf-8',
  '.js':'text/javascript; charset=utf-8',
  '.css':'text/css; charset=utf-8',
  '.json':'application/json; charset=utf-8',
  '.png':'image/png','.svg':'image/svg+xml','.ico':'image/x-icon'
};

const server = http.createServer((req,res)=>{
  const url = new URL(req.url, 'http://localhost');

  // 实时代理端点
  const lm = url.pathname.match(/^\/api\/live\/(\w+)$/);
  if(lm){
    getLive(lm[1]).then(data=>{
      if(!data){ res.writeHead(404,{'Content-Type':'application/json'}); res.end(JSON.stringify({success:false,msg:'unknown source'})); return; }
      res.writeHead(200,{'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Cache-Control':'no-store'});
      res.end(JSON.stringify(data));
    }).catch(e=>{
      res.writeHead(502,{'Content-Type':'application/json'});
      res.end(JSON.stringify({success:false,msg:'live fetch failed',detail:String(e&&e.message)}));
    });
    return;
  }

  // API 反向代理
  if(url.pathname.startsWith('/api/')){
    const target = 'https://' + UPSTREAM + url.pathname + url.search;
    const proxy = https.get(target, {method: req.method, headers:{'Accept':'application/json'}}, (up)=>{
      res.writeHead(up.statusCode, {'Content-Type':'application/json','Access-Control-Allow-Origin':'*'});
      up.pipe(res);
    });
    proxy.on('error', e=>{ res.writeHead(502,{'Content-Type':'application/json'}); res.end(JSON.stringify({status:false,code:502,msg:'代理错误'})); });
    return;
  }

  // 静态文件
  let fp = url.pathname === '/' ? path.join(ROOT,'index.html') : path.join(ROOT, decodeURIComponent(url.pathname));
  if(!fs.existsSync(fp) || fs.statSync(fp).isDirectory()){ fp = path.join(ROOT,'index.html'); }
  const ext = path.extname(fp);
  res.writeHead(200, {
    'Content-Type': mime[ext]||'application/octet-stream',
    'Cache-Control':'no-store, no-cache, must-revalidate, max-age=0',
    'Pragma':'no-cache',
    'Expires':'0'
  });
  fs.createReadStream(fp).pipe(res);
});

server.listen(PORT, ()=>console.log('CF server on :'+PORT));
