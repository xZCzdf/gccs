# CF 优选节点 — Android App

有科技感 UI 的 CloudFlare 优选 IP 测速应用。WebView 壳 + 内置 HTML。

## 项目结构
```
android-app/
├── build.gradle
├── settings.gradle
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/index.html        # 界面（WebView 加载）
        ├── java/com/cf/preferred/MainActivity.java
        └── res/
            ├── values/themes.xml
            └── drawable/ic_launcher.xml
```

## 构建方式（Android Studio）
1. Android Studio 打开 `android-app` 目录
2. 等待 Gradle 同步完成（需联网下载依赖）
3. Run 或 Build APK

## 命令行构建
```bash
# 需 JDK 17+ 与 Android SDK
./gradlew assembleDebug
# 产物：app/build/outputs/apk/debug/app-debug.apk
```

## 说明
- 界面数据来自 api.uouin.com/cloudflare.html 快照，内置在 assets/index.html
- 若要实时数据，可在 index.html 中把 data 源改为后端 API
